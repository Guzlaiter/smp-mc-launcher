import tkinter as tk
import ctypes
import sys
from pathlib import Path


class CustomWindow(tk.Tk):
    """
    Кастомное окно без системной рамки Windows.
    Содержит title bar, drag-and-drop, кнопку закрытия и фикс панели задач.
    Внутри self.content — контейнер, куда добавляется MainWindow.
    """

    TITLEBAR_BG = "#111111"
    TITLEBAR_FG = "#888888"
    BG          = "#1e1e1e"
    RED         = "#c42b1c"
    CONTENT_BG  = "#2b2b2b"

    def __init__(self, title="Launcher", size=(1100, 700), assets_dir=None):
        super().__init__()
        self.title(title)
        self.geometry(f"{size[0]}x{size[1]}")
        self.configure(bg=self.BG)
        self.overrideredirect(True)

        if assets_dir is None:
            assets_dir = Path(__file__).resolve().parent.parent / "assets"
        self.assets_dir = Path(assets_dir)

        self._photos = {}
        self._drag_x = 0
        self._drag_y = 0

        self._build_titlebar()
        self._setup_icons()

        # Контейнер для MainWindow
        self.content = tk.Frame(self, bg=self.CONTENT_BG)
        self.content.pack(side="top", fill="both", expand=True)

        # Фикс панели задач с задержкой (важно!)
        self.after(300, self._fix_taskbar_icon)

    # ------------------------------------------------------------------
    # Title bar
    # ------------------------------------------------------------------
    def _build_titlebar(self):
        self.titlebar = tk.Frame(self, bg=self.TITLEBAR_BG, height=30)
        self.titlebar.pack(side="top", fill="x")
        self.titlebar.pack_propagate(False)

        self.titlebar.bind("<ButtonPress-1>", self._start_drag)
        self.titlebar.bind("<ButtonRelease-1>", self._stop_drag)
        self.titlebar.bind("<B1-Motion>", self._do_drag)

        self.title_label = tk.Label(
            self.titlebar, text="Create Launcher",
            bg=self.TITLEBAR_BG, fg=self.TITLEBAR_FG,
            font=("Arial", 9),
        )
        self.title_label.pack(side="left", padx=10)
        self.title_label.bind("<ButtonPress-1>", self._start_drag)
        self.title_label.bind("<ButtonRelease-1>", self._stop_drag)
        self.title_label.bind("<B1-Motion>", self._do_drag)

        self.close_btn = tk.Button(
            self.titlebar, text="✕",
            bg=self.TITLEBAR_BG, fg="white", bd=0,
            font=("Arial", 12, "bold"),
            command=self._on_close, padx=15,
        )
        self.close_btn.pack(side="right", fill="y")
        self.close_btn.bind("<Enter>", lambda e: self.close_btn.config(bg=self.RED))
        self.close_btn.bind("<Leave>", lambda e: self.close_btn.config(bg=self.TITLEBAR_BG))

    def set_title_text(self, text: str):
        """Обновляет название окна и title bar."""
        self.title_label.config(text=text)
        self.title(text)

    # ------------------------------------------------------------------
    # Иконки
    # ------------------------------------------------------------------
    def _setup_icons(self):
        # Для заголовка и панели задач (PNG)
        try:
            png = tk.PhotoImage(file=str(self.assets_dir / "logo.png"))
            self._photos["icon"] = png
            self.iconphoto(True, png)
        except Exception:
            pass

        # Для панели задач (ICO, Windows нативно)
        try:
            self.iconbitmap(str(self.assets_dir / "logo.ico"))
        except Exception:
            pass

    def _fix_taskbar_icon(self):
        """Делает окно видимым в панели задач Windows, несмотря на overrideredirect."""
        try:
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id()) or self.winfo_id()
            GWL_EXSTYLE     = -20
            WS_EX_APPWINDOW = 0x00040000
            WS_EX_TOOLWINDOW = 0x00000080
            SWP_FLAGS = 0x0027  # NOMOVE | NOSIZE | NOZORDER | FRAMECHANGED

            ex = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            ex = (ex & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, ex)
            ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, 0, 0, SWP_FLAGS)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Drag
    # ------------------------------------------------------------------
    def _start_drag(self, event):
        self._drag_x = event.x
        self._drag_y = event.y

    def _stop_drag(self, event):
        self._drag_x = 0
        self._drag_y = 0

    def _do_drag(self, event):
        if self._drag_x == 0 and self._drag_y == 0:
            return
        x = self.winfo_pointerx() - self._drag_x
        y = self.winfo_pointery() - self._drag_y
        self.geometry(f"+{x}+{y}")

    # ------------------------------------------------------------------
    # Close
    # ------------------------------------------------------------------
    def _on_close(self):
        self.destroy()
        sys.exit(0)