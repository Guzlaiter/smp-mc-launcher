import threading
import tkinter as tk
from tkinter import font as tkfont, messagebox
from pathlib import Path

from app.config import (
    save_config, GITHUB_REPO, TEST_RELEASE_DIR, is_test_mode,
)
from app.github_updater import GithubUpdater, LocalUpdater, UpdateError
from app.minecraft import (
    MinecraftError,
    install_minecraft,
    install_neoforge,
    build_launch_command,
    launch_minecraft,
    installed_version_ids,
)
from app.utils import log, human_size
from ui.settings import SettingsTab
from ui.home import HomePage


class MainWindow(tk.Frame):
    """Оболочка: сайдбар + контейнер для страниц (home / settings)."""

    BG       = "#2b2b2b"
    SIDEBAR  = "#1a1a1a"
    ACCENT   = "#8B5A2B"
    TEXT     = "#e0e0e0"
    RED      = "#c42b1c"

    def __init__(self, master, cfg: dict, app):
        super().__init__(master.content, bg=self.BG)
        self.pack(fill="both", expand=True)

        self.root = master           # CustomWindow
        self.app = app
        self.cfg = cfg
        self.assets = master.assets_dir

        # Апдейтер
        self.test_mode = is_test_mode()
        if self.test_mode:
            self.updater = LocalUpdater(TEST_RELEASE_DIR)
        else:
            self.updater = GithubUpdater(GITHUB_REPO) if "/" in GITHUB_REPO else None

        self._photos = {}
        self.normal_font = tkfont.Font(family="Arial", size=10)
        self.title_font  = tkfont.Font(family="Impact", size=24)

        self._build_sidebar()

        # Контейнер страниц
        self.pages = tk.Frame(self, bg=self.BG)
        self.pages.pack(side="top", fill="both", expand=True)

        self.home_page = HomePage(
            self.pages,
            assets=self.assets,
            cfg=self.cfg,
            on_play=self._on_play,
        )
        self.settings_page = SettingsTab(
            self.pages,
            cfg=self.cfg,
            on_save=self._save_settings,
        )

        self._show_home()

        # Автообновление
        if self.updater and self.cfg.get("auto_check_updates", True):
            self.root.after(500, self._check_updates_async)
        elif not self.updater:
            self.home_page.set_status("Источник сборки не настроен", self.RED)

    # ==================================================================
    #                            SIDEBAR
    # ==================================================================
    def _build_sidebar(self):
        sb = tk.Frame(self, bg=self.SIDEBAR, width=200)
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)

        # Логотип
        try:
            logo = tk.PhotoImage(file=str(self.assets / "logo.png"))
            w = logo.width()
            factor = max(1, w // 160)
            self._photos["logo"] = logo.subsample(factor, factor)
            tk.Label(sb, image=self._photos["logo"], bg=self.SIDEBAR).pack(pady=20)
        except Exception as e:
            log.warning(f"Logo: {e}")
            tk.Label(sb, text="CREATE\nMECHANICA",
                     font=self.title_font, bg=self.SIDEBAR,
                     fg=self.ACCENT, justify="center").pack(pady=20)

        self._menu_button(sb, "Главная",    self._show_home)
        self._menu_button(sb, "Обновления", self._on_check_updates)
        self._menu_button(sb, "Моды",       lambda: self.home_page.set_status("Раздел в разработке"))
        self._menu_button(sb, "Настройки",  self._show_settings)

    def _menu_button(self, parent, text, command):
        btn = tk.Button(
            parent, text=text, font=self.normal_font,
            bg=self.SIDEBAR, fg=self.TEXT,
            bd=0, anchor="w", padx=20, pady=10,
            activebackground=self.ACCENT, activeforeground="white",
            command=command,
        )
        btn.pack(fill="x")
        btn.bind("<Enter>", lambda e: btn.config(bg="#252525"))
        btn.bind("<Leave>", lambda e: btn.config(bg=self.SIDEBAR))

    # ==================================================================
    #                       НАВИГАЦИЯ
    # ==================================================================
    def _show_home(self):
        self.settings_page.pack_forget()
        self.home_page.pack(fill="both", expand=True)

    def _show_settings(self):
        self.home_page.pack_forget()
        self.settings_page.pack(fill="both", expand=True, padx=20, pady=20)

    def _save_settings(self, new_cfg: dict):
        self.cfg = new_cfg
        save_config(self.cfg)
        self.root.set_title_text(self.cfg.get("server_name", "Create Launcher"))

    # ==================================================================
    #                       ОБНОВЛЕНИЯ
    # ==================================================================
    def _on_check_updates(self):
        self._show_home()
        self._check_updates_async()

    def _check_updates_async(self):
        if not self.updater:
            self.home_page.set_status("Источник сборки не настроен", self.RED)
            return
        threading.Thread(target=self._check_updates, daemon=True).start()

    def _check_updates(self):
        try:
            self._ui_status("Проверка источника...")

            if self.test_mode:
                tag = self.updater.get_local_version()
            else:
                release = self.updater.get_latest_release()
                tag = release.get("tag_name", "?")

            local_ver = self._read_local_version()

            if local_ver == tag:
                self._ui_status(f"Сборка актуальна ({tag})", "#8ee08e")
                return

            self._ui_status(f"Доступна версия {tag}", "#f0b040")

            if messagebox.askyesno(
                "Обновление",
                f"Доступна новая версия сборки {tag}.\nОбновить сейчас?",
            ):
                self._do_update(tag)
        except UpdateError as e:
            self._ui_status(str(e), self.RED)
        except Exception as e:
            log.exception("check failed")
            self._ui_status(f"Ошибка: {e}", self.RED)

    def _do_update(self, tag: str):
        threading.Thread(target=self._update_worker, args=(tag,), daemon=True).start()

    def _update_worker(self, tag: str):
        game_dir   = Path(self.cfg["game_directory"])
        client_dir = game_dir / "client"
        tmp_dir    = game_dir / "tmp"
        tmp_dir.mkdir(parents=True, exist_ok=True)

        try:
            if self.test_mode:
                mrpack_name = next(self.updater.dir.glob("*.mrpack")).name
            else:
                release = self.updater.get_latest_release()
                asset = self.updater.find_mrpack_asset(release)
                mrpack_name = asset["name"]
        except Exception as e:
            log.exception("get mrpack name failed")
            self._ui_status(f"Ошибка: {e}", self.RED)
            return

        mrpack_path = tmp_dir / mrpack_name

        def dl_cb(done, total):
            pct = int(done / total * 100) if total else 0
            txt = f"{mrpack_name}  {human_size(done)} / {human_size(total)}"
            self._ui_progress(pct, txt)

        try:
            if self.test_mode:
                self._ui_status(f"Копирование {mrpack_name}...")
                self.updater.copy_asset(mrpack_path, progress_cb=dl_cb)
            else:
                release = self.updater.get_latest_release()
                asset = self.updater.find_mrpack_asset(release)
                self._ui_status(f"Скачивание {mrpack_name}...")
                self.updater.download_asset(asset, mrpack_path, progress_cb=dl_cb)
        except Exception as e:
            log.exception("get mrpack failed")
            self._ui_status(f"Ошибка получения сборки: {e}", self.RED)
            return

        def up_cb(stage, idx, total, msg):
            pct = int(idx / total * 100) if total else 0
            self._ui_progress(pct, f"{msg}  ({idx}/{total})")

        try:
            self._ui_status("Установка сборки...")
            info = self.updater.install_mrpack(mrpack_path, client_dir, progress_cb=up_cb)
        except Exception as e:
            log.exception("install mrpack failed")
            self._ui_status(f"Ошибка установки: {e}", self.RED)
            return

        self._write_local_version(tag)
        self.cfg["minecraft_version"] = info.get("minecraft") or self.cfg["minecraft_version"]
        self.cfg["neoforge_version"]  = info.get("neoforge") or ""
        save_config(self.cfg)

        self._ui_status(f"Готово ({tag})", "#8ee08e")
        self._ui_progress(100, "Готово")

    # ==================================================================
    #                       ИГРА
    # ==================================================================
    def _on_play(self):
        self.home_page.set_play_enabled(False)
        self._ui_status("Подготовка...")
        threading.Thread(target=self._play, daemon=True).start()

    def _play(self):
        try:
            game_dir   = Path(self.cfg["game_directory"])
            mc_dir     = game_dir / "minecraft"
            client_dir = game_dir / "client"
            mc_dir.mkdir(parents=True, exist_ok=True)
            client_dir.mkdir(parents=True, exist_ok=True)

            mc_version = self.cfg["minecraft_version"]
            nf_version = self.cfg.get("neoforge_version", "")
            java_path  = self.cfg.get("java_path", "")
            installed  = installed_version_ids(mc_dir)

            if mc_version not in installed:
                self._ui_status("Установка Minecraft...")
                install_minecraft(mc_dir, mc_version, java_path, self._mc_progress)

            if nf_version:
                has_nf = any("neoforge" in v.lower() and nf_version in v
                             for v in installed)
                if not has_nf:
                    self._ui_status("Установка NeoForge...")
                    install_neoforge(mc_dir, mc_version, nf_version,
                                     java_path, self._mc_progress)

            self._ui_status("Запуск Minecraft...")
            cmd = build_launch_command(
                mc_dir=mc_dir,
                client_dir=client_dir,
                username=self.cfg.get("username", "Player"),
                token="0",
                mc_version=mc_version,
                nf_version=nf_version,
                ram_mb=int(self.cfg.get("ram_mb", 4096)),
                java_path=java_path,
            )
            launch_minecraft(cmd, cwd=client_dir)

            self._ui_status("Minecraft запущен", "#8ee08e")

            if self.cfg.get("close_after_launch"):
                self.root.after(500, self.root._on_close)
        except MinecraftError as e:
            self._ui_status(f"Ошибка: {e}", self.RED)
        except Exception as e:
            log.exception("play error")
            self._ui_status(f"Ошибка: {e}", self.RED)
        finally:
            self.root.after(0, lambda: self.home_page.set_play_enabled(True))

    def _mc_progress(self, status: str, current: int, total: int):
        pct = int(current / total * 100) if total else 0
        self._ui_progress(pct, f"{status}  {current}/{total}")

    # ==================================================================
    #                ХЕЛПЕРЫ ДЛЯ UI-ОБНОВЛЕНИЙ
    # ==================================================================
    def _ui_status(self, text: str, color: str = "#e7d3a7"):
        self.root.after(0, lambda: self.home_page.set_status(text, color))

    def _ui_progress(self, pct: int, text: str = ""):
        self.root.after(0, lambda: self.home_page.update_progress(pct, text))

    # ==================================================================
    #                       ВЕРСИЯ
    # ==================================================================
    def _version_file(self) -> Path:
        return Path(self.cfg["game_directory"]) / "pack_version.txt"

    def _read_local_version(self) -> str:
        f = self._version_file()
        return f.read_text(encoding="utf-8").strip() if f.exists() else ""

    def _write_local_version(self, v: str) -> None:
        self._version_file().write_text(v, encoding="utf-8")