# ui/__init__.py
from .settings import SettingsTab

__all__ = ["SettingsTab"]