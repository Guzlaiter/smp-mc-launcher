import sys
from pathlib import Path
from tkinter import messagebox

from app.config import load_config
from app.utils import log
from ui.main_window import MainWindow
from ui.widgets import CustomWindow


ASSETS = Path(__file__).resolve().parent / "assets"


class LauncherApp(CustomWindow):
    def __init__(self):
        super().__init__(title="Create SMP — Launcher", size=(1000, 650))
        self.cfg = load_config()
        self.assets = ASSETS

        MainWindow(self, self.cfg, app=self)


def main():
    try:
        app = LauncherApp()
        app.mainloop()
    except Exception as e:
        log.exception("fatal")
        try:
            messagebox.showerror("Ошибка", f"Критическая ошибка: {e}")
        except Exception:
            pass
        sys.exit(1)


if __name__ == "__main__":
    main()